def hamming_encode(data):
    # Convert the data to a list of integers
    data_bits = [int(bit) for bit in data]

    # Calculate parity bits
    p1 = (data_bits[0] + data_bits[1] + data_bits[3]) % 2
    p2 = (data_bits[0] + data_bits[2] + data_bits[3]) % 2
    p3 = (data_bits[1] + data_bits[2] + data_bits[3]) % 2

    # Construct the codeword
    codeword = [data_bits[0], data_bits[1], data_bits[2], p1, data_bits[3], p2, p3]

    # Convert the codeword to a string
    codeword_str = ''.join(str(bit) for bit in codeword)
    return codeword_str

# Test the function with a sample data word
data_word = '1010'
encoded_word = hamming_encode(data_word)
print("Encoded codeword:", encoded_word)

