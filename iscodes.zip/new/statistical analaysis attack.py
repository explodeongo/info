import string
from collections import Counter

def caesar_cipher(text, key):
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            shift = ord('a') if char.islower() else ord('A')
            encrypted_text += chr((ord(char) - shift + key) % 26 + shift)
        else:
            encrypted_text += char
    return encrypted_text

def frequency_analysis(text):
    # Count the occurrences of each letter in the text
    letter_count = Counter(char.lower() for char in text if char.isalpha())
    # Calculate the frequency distribution
    total_letters = sum(letter_count.values())
    frequency_distribution = {letter: count / total_letters for letter, count in letter_count.items()}
    return frequency_distribution

def encrypt():
    plaintext = input("Enter the plaintext: ")
    shift = int(input("Enter the Caesar cipher shift key: "))
    encrypted_text = caesar_cipher(plaintext, shift)
    print("Encrypted text:", encrypted_text)

def decrypt():
    ciphertext = input("Enter the ciphertext: ")
    shift = int(input("Enter the Caesar cipher shift key: "))
    decrypted_text = caesar_cipher(ciphertext, -shift)  # Using the negative shift for decryption
    print("Decrypted text:", decrypted_text)


def decrypt_with_statistical_attack(ciphertext):
    # Expected frequency distribution of English text
    expected_distribution = {
        'a': 0.08167, 'b': 0.01492, 'c': 0.02782, 'd': 0.04253, 'e': 0.12702,
        'f': 0.02228, 'g': 0.02015, 'h': 0.06094, 'i': 0.06966, 'j': 0.00153,
        'k': 0.00772, 'l': 0.04025, 'm': 0.02406, 'n': 0.06749, 'o': 0.07507,
        'p': 0.01929, 'q': 0.00095, 'r': 0.05987, 's': 0.06327, 't': 0.09056,
        'u': 0.02758, 'v': 0.00978, 'w': 0.02360, 'x': 0.00150, 'y': 0.01974,
        'z': 0.00074
    }

    # Perform the statistical analysis attack
    best_shift = None
    best_similarity = float('-inf')
    for shift in range(26):
        shifted_text = caesar_cipher(ciphertext, -shift)
        observed_distribution = frequency_analysis(shifted_text)
        # Calculate similarity using the sum of squared differences
        similarity = sum((observed_distribution.get(letter, 0) - expected_distribution.get(letter, 0)) ** 2
                         for letter in string.ascii_lowercase)
        if similarity > best_similarity:
            best_similarity = similarity
            best_shift = shift

    # Decrypt the ciphertext using the best shift
    decrypted_text = caesar_cipher(ciphertext, -best_shift)
    return decrypted_text, best_shift




def main():
    while True:
        print("\nMenu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            encrypt()
        elif choice == "2":
            decrypt()
        elif choice == "3":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()




