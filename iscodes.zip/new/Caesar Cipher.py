# implement Caesar Cipher
def caesar_cipher(text, shift, encrypt=True):
    result = ''
    for char in text:
        if char.isalpha():
            is_upper = char.isupper()
            factor = 1 if encrypt else -1
            shifted_char = chr((ord(char) - ord('A' if is_upper else 'a') + factor * shift) % 26 + ord('A' if is_upper else 'a'))
            result += shifted_char
        else:
            result += char
    return result

def brute_force(text):
    for k in range(1,27):
        result = ''
        for char in text:
            if char.isalpha():
                is_upper = char.isupper()
                shifted_char = chr((ord(char) - ord('A' if is_upper else 'a') - k) % 26 + ord('A' if is_upper else 'a'))
                result += shifted_char
            else:
                result += char
        print(f'Is the Decrypted Text is {result} ?')
        ch = int(input('Enter 1 for yes and 2 for no : '))
        if ch == 1:
            return result
        else:
            continue

def menu():
    while True:
        print("Caesar Cipher Menu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Brute Force Attack")
        print("4. Exit")
        
        choice = input("Enter your choice (1/2/3/4): ")
        
        if choice == '1':
            plaintext = input("Enter the plaintext: ")
            shift_amount = int(input("Enter the shift amount: "))
            ciphertext = caesar_cipher(plaintext, shift_amount)
            print(f'Encrypted text: {ciphertext}')
        elif choice == '2':
            ciphertext = input("Enter the ciphertext: ")
            shift_amount = int(input("Enter the shift amount: "))
            decrypted_text = caesar_cipher(ciphertext, shift_amount, encrypt=False)
            print(f'Decrypted text: {decrypted_text}')
        elif choice == '3':
            ciphertext = input("Enter the ciphertext: ")
            decrypted_text = brute_force(ciphertext)
            print(f'Decrypted text: {decrypted_text}')
        elif choice == '4':
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please enter 1, 2, 3 or 4.")

if __name__ == "__main__":
    menu()
