def caesar_cipher(text, key):
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            shift = ord('a') if char.islower() else ord('A')
            encrypted_text += chr((ord(char) - shift + key) % 26 + shift)
        else:
            encrypted_text += char
    return encrypted_text

def columnar_transposition(text, key):
    rows = len(text) // key + (1 if len(text) % key != 0 else 0)
    matrix = [['' for _ in range(rows)] for _ in range(key)]
    for i, char in enumerate(text):
        matrix[i // rows][i % rows] = char
    transposed_text = ''.join(''.join(row) for row in matrix)
    return transposed_text

def encrypt():
    plaintext = input("Enter the plaintext: ")
    caesar_key = int(input("Enter the Caesar cipher shift key: "))
    transposition_key = int(input("Enter the columnar transposition key: "))

    # Step 1: Apply Caesar Cipher (Substitution)
    step1_encrypted = caesar_cipher(plaintext, caesar_key)
    # Step 2: Apply Columnar Transposition (Transposition)
    encrypted_text = columnar_transposition(step1_encrypted, transposition_key)

    print("Encrypted text:", encrypted_text)

def decrypt():
    ciphertext = input("Enter the ciphertext: ")
    caesar_key = int(input("Enter the Caesar cipher shift key: "))
    transposition_key = int(input("Enter the columnar transposition key: "))

    # Step 1: Reverse Columnar Transposition (Transposition)
    step1_decrypted = columnar_transposition(ciphertext, transposition_key)
    # Step 2: Reverse Caesar Cipher (Substitution)
    decrypted_text = caesar_cipher(step1_decrypted, -caesar_key)

    print("Decrypted text:", decrypted_text)

def main():
    while True:
        print("\nMenu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            encrypt()
        elif choice == "2":
            decrypt()
        elif choice == "3":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()

