# implement Vigenere Cipher
def vigenere_cipher(text, key, encrypt=True):
    factor = 1 if encrypt else -1
    key = list(key)
    key_l = key*(len(text)//len(key)) + key[:len(text)%len(key)]
    text = [ord(char) - ord('A') for char in text if char.isalpha()]
    key = [ord(char) - ord('A') for char in key_l]
    result = [chr(((x+factor*y)%26 + ord('A'))) for x,y in zip(text,key)]
    return ''.join(result)

def menu():
    while True:
        print("Vigenere Cipher Menu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Exit")

        choice = input("Enter your choice (1/2/3): ")

        if choice == '1':
            plaintext = input("Enter the plaintext: ").upper()
            key = input("Enter the key: ").upper()
            ciphertext = vigenere_cipher(plaintext, key)
            print(f'Encrypted text: {ciphertext}')
        elif choice == '2':
            ciphertext = input("Enter the ciphertext: ").upper()
            key = input("Enter the key: ").upper()
            decrypted_text = vigenere_cipher(ciphertext, key, encrypt=False)
            print(f'Decrypted text: {decrypted_text}')

        elif choice == '3':
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please enter 1, 2 or 3.")

if __name__ == "__main__":
    menu()



