def xor_cipher(message, key):
    result = ""
    for char in message:
        result += chr(ord(char) ^ key)
    return result

def main():
    while True:
        print("\nXOR Cipher Menu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            message = input("Enter the message to encrypt: ")
            key = int(input("Enter the key character: "))
            encrypted_message = xor_cipher(message, key)
            print("Encrypted message:", encrypted_message)
        elif choice == "2":
            message = input("Enter the message to decrypt: ")
            key = int(input("Enter the key character: "))
            decrypted_message = xor_cipher(message, key)
            print("Decrypted message:", decrypted_message)
        elif choice == "3":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please choose again.")

if __name__ == "__main__":
    main()

