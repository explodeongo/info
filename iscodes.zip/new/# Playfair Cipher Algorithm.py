# Playfair Cipher Algorithm
def prepare_key(key):
    key = key.upper().replace("J", "I")
    key_set = set(key)
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"

    for char in key_set:
        if char in alphabet:
            alphabet = alphabet.replace(char, "")
    key_matrix = [['' for _ in range(5)] for _ in range(5)]

    k = 0
    for i in range(5):
        for j in range(5):
            if k < len(key):
                key_matrix[i][j] = key[k]
                k += 1
            else:
                key_matrix[i][j] = alphabet[0]
                alphabet = alphabet[1:]

    return key_matrix

def find_char(char, key_matrix):
    for i, row in enumerate(key_matrix):
        if char in row:
            return i, row.index(char)

def playfair_encrypt(plaintext, key_matrix):

    plaintext = plaintext.upper().replace("J", "I").replace(" ", "")
    ciphertext = ""
    len1 = (2*len(plaintext)) - len(set(plaintext))
    plaintext_pairs=[]
    i=0
    while(i<len1):
        if(i+1==len(plaintext)):
            plaintext = plaintext+'Z'
            plaintext_pairs.append(plaintext[i:i + 2])
            break
        else:
            if plaintext[i] != plaintext[i + 1]:
                plaintext_pairs.append(plaintext[i:i + 2])
            else:
                plaintext_pairs.append(plaintext[i] + 'X')
                plaintext = plaintext[:i+1] + 'X' + plaintext[i+1:]
        if i+2==len(plaintext):
            break
        i = i+2
    for pair in plaintext_pairs:
        char1, char2 = pair[0], pair[1]

        # Find indices of characters in the key matrix
        row1, col1 = find_char(char1, key_matrix)
        row2, col2 = find_char(char2, key_matrix)

        # Encrypt based on the Playfair rules
        if row1 == row2:
            ciphertext += key_matrix[row1][(col1 + 1) % 5] + key_matrix[row2][(col2 + 1) % 5]
        elif col1 == col2:
            ciphertext += key_matrix[(row1 + 1) % 5][col1] + key_matrix[(row2 + 1) % 5][col2]
        else:
            ciphertext += key_matrix[row1][col2] + key_matrix[row2][col1]

    return ciphertext

def playfair_decrypt(ciphertext, key_matrix):
    plaintext = ""

    for i in range(0, len(ciphertext), 2):
        char1, char2 = ciphertext[i], ciphertext[i + 1]

        row1, col1 = find_char(char1, key_matrix)
        row2, col2 = find_char(char2, key_matrix)

        if row1 == row2:
            plaintext += key_matrix[row1][(col1 - 1) % 5] + key_matrix[row2][(col2 - 1) % 5]
        elif col1 == col2:
            plaintext += key_matrix[(row1 - 1) % 5][col1] + key_matrix[(row2 - 1) % 5][col2]
        else:
            plaintext += key_matrix[row1][col2] + key_matrix[row2][col1]

    return plaintext

def main():
    key = input("Enter the key for Playfair cipher: ")
    key_matrix = prepare_key(key)
    print(key_matrix)
    while True:
        print("\nMenu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Quit")

        choice = input("Enter your choice (1/2/3): ")

        if choice == "1":
            plaintext = input("Enter the plaintext: ")
            ciphertext = playfair_encrypt(plaintext, key_matrix)
            print("Encrypted text:", ciphertext)
        elif choice == "2":
            ciphertext = input("Enter the ciphertext: ")
            plaintext = playfair_decrypt(ciphertext, key_matrix)
            print("Decrypted text:", plaintext)
        elif choice == "3":
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()


