def hamming_encode(data):
    # Convert the data to a list of integers
    data_bits = [int(bit) for bit in data]

    # Calculate parity bits
    p1 = (data_bits[0] + data_bits[1] + data_bits[2] + data_bits[3]) % 2
    p2 = (data_bits[0] + data_bits[1] + data_bits[3]) % 2
    p3 = (data_bits[0] + data_bits[2] + data_bits[3]) % 2
    p4 = (data_bits[1] + data_bits[2] + data_bits[3]) % 2

    # Construct the codeword
    codeword = [p1, p2, data_bits[0], p3, data_bits[1], data_bits[2], data_bits[3], p4]

    # Convert the codeword to a string
    codeword_str = ''.join(str(bit) for bit in codeword)
    return codeword_str

def hamming_correct(codeword):
    # Convert the received codeword to a list of integers
    received_codeword = [int(bit) for bit in codeword]

    # Calculate syndrome bits
    s1 = (received_codeword[0] + received_codeword[2] + received_codeword[4] + received_codeword[6]) % 2
    s2 = (received_codeword[1] + received_codeword[2] + received_codeword[5] + received_codeword[6]) % 2
    s3 = (received_codeword[3] + received_codeword[4] + received_codeword[5] + received_codeword[6]) % 2

    # Calculate the error position
    error_pos = s1 * 1 + s2 * 2 + s3 * 4

    # Correct the error
    if error_pos != 0:
        received_codeword[error_pos - 1] = 1 - received_codeword[error_pos - 1]

    # Extract the original data bits
    corrected_data = [received_codeword[2], received_codeword[4], received_codeword[5], received_codeword[6]]

    # Convert the corrected data bits to a string
    corrected_data_str = ''.join(str(bit) for bit in corrected_data)
    return corrected_data_str

def main():
    while True:
        print("\nMenu:")
        print("1. Encode")
        print("2. Introduce Error")
        print("3. Correct Error")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            data_word = input("Enter 4-bit data word to encode: ")
            encoded_word = hamming_encode(data_word)
            print("Encoded codeword:", encoded_word)
        elif choice == "2":
            received_codeword = input("Enter received codeword: ")
            error_position = int(input("Enter error position (1-8): "))
            received_codeword = received_codeword[:error_position-1] + str(1-int(received_codeword[error_position-1])) + received_codeword[error_position:]
            print("Codeword with error:", received_codeword)
        elif choice == "3":
            received_codeword = input("Enter received codeword: ")
            corrected_data = hamming_correct(received_codeword)
            print("Corrected data:", corrected_data)
        elif choice == "4":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
