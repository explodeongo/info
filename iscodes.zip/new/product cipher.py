def caesar_cipher(text, key):
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            shift = ord('a') if char.islower() else ord('A')
            encrypted_text += chr((ord(char) - shift + key) % 26 + shift)
        else:
            encrypted_text += char
    return encrypted_text

def columnar_transposition(text, key):
    rows = len(text) // key + (1 if len(text) % key != 0 else 0)
    matrix = [['' for _ in range(key)] for _ in range(rows)]
    for i, char in enumerate(text):
        matrix[i // key][i % key] = char
    transposed_text = ''.join(''.join(row) for row in zip(*matrix))
    return transposed_text

def encrypt(text, key):
    # Step 1: Apply Caesar Cipher (Substitution)
    step1_encrypted = caesar_cipher(text, key)
    # Step 2: Apply Columnar Transposition (Transposition)
    step2_encrypted = columnar_transposition(step1_encrypted, len(str(key)))
    return step2_encrypted

def decrypt(text, key):
    # Step 1: Reverse Columnar Transposition (Transposition)
    step1_decrypted = columnar_transposition(text, len(str(key)))
    # Step 2: Reverse Caesar Cipher (Substitution)
    step2_decrypted = caesar_cipher(step1_decrypted, -key)
    return step2_decrypted

def main():
    while True:
        print("\nMenu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            plaintext = input("Enter the plaintext: ")
            key = input("Enter the encryption key (Caesar cipher shift): ")
            encrypted_text = encrypt(plaintext, int(key))
            print("Encrypted text:", encrypted_text)

        elif choice == "2":
            ciphertext = input("Enter the ciphertext: ")
            key = input("Enter the decryption key (Caesar cipher shift): ")
            decrypted_text = decrypt(ciphertext, int(key))
            print("Decrypted text:", decrypted_text)

        elif choice == "3":
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
