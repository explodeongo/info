import math
def columnar_encrypt(message, key):
    encrypted_message = ''
    num_cols = len(key)
    num_rows = math.ceil(len(message)/num_cols)  # Ceiling division
    matrix = [[' ' for _ in range(num_cols)] for _ in range(num_rows)]

    for i in range(num_rows):
        for j in range(num_cols):
            if(len(message)==0):
                break
            matrix[i][j] = message[0]
            message = message[1:]
    key_order = sorted(range(num_cols), key=lambda k: key[k])
    for i in key_order:
        for j in range(num_rows):
            encrypted_message += matrix[j][i]
    return encrypted_message

def columnar_decrypt(message, key):
    decrypted_message= ''
    key_order = sorted(range(len(key)), key=lambda k: key[k])
    num_cols = len(key)
    num_rows = int(len(message)/num_cols)  # Ceiling division
    matrix = [['' for _ in range(num_cols)] for _ in range(num_rows)]

    for i in key_order:
        for j in range(num_rows):
            matrix[j][i] = message[0]
            message = message[1:]
    for i in range(num_rows):
        for j in range(num_cols):
            decrypted_message += matrix[i][j]
    decrypted_message = decrypted_message.rstrip()
    return decrypted_message

def main():
    key = input("Enter the key: ")
    while True:
        print("\nMenu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Quit")

        choice = input("Enter your choice (1/2/3): ")

        if choice == "1":
            plaintext = input("Enter the plaintext: ")
            ciphertext = columnar_encrypt(plaintext, key)
            print("Encrypted text:", ciphertext)
        elif choice == "2":
            ciphertext = input("Enter the ciphertext: ")
            plaintext = columnar_decrypt(ciphertext, key)
            print("Decrypted text:", plaintext)
        elif choice == "3":
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()

