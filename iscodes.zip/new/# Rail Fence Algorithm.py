# Rail Fence Algorithm
def railfence_encrypt(plaintext, rails):
    n = len(plaintext)
    matrix =[['' for _ in range(n)] for _ in range(rails)]
    row, col, direction = 0,0,1 # direction 1 for down and -1 for up
    for char in plaintext:
        matrix[row][col] = char
        row += direction

        if row == rails-1 or row == 0:
            direction *= -1
        col += 1

    ciphertext=""
    for i in range(rails):
        ciphertext += ''.join(matrix[i])

    return ciphertext

def railfence_decrypt(ciphertext, rails):
    n = len(ciphertext)
    matrix =[['' for _ in range(n)] for _ in range(rails)]
    row, col, direction = 0,0,1 # direction 1 for down and -1 for up
    for char in ciphertext:
        matrix[row][col] = '*'
        row += direction

        if row == rails-1 or row == 0:
            direction *= -1
        col += 1
    index=0
    for i in range(rails):
        for j in range(len(ciphertext)):
            if ((matrix[i][j] == '*') and
            (index < len(ciphertext))):
                matrix[i][j] = ciphertext[index]
                index += 1
    plaintext=""
    row, col, direction = 0,0,1 # direction 1 for down and -1 for up
    for char in ciphertext:
        plaintext += matrix[row][col]
        row += direction

        if row == rails-1 or row == 0:
            direction *= -1
        col += 1

    return plaintext

def main():
    rails = int(input("Enter the number of rails for RailFence cipher: "))
    while True:
        print("\nMenu:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Quit")

        choice = input("Enter your choice (1/2/3): ")

        if choice == "1":
            plaintext = input("Enter the plaintext: ")
            ciphertext = railfence_encrypt(plaintext, rails)
            print("Encrypted text:", ciphertext)
        elif choice == "2":
            ciphertext = input("Enter the ciphertext: ")
            plaintext = railfence_decrypt(ciphertext, rails)
            print("Decrypted text:", plaintext)
        elif choice == "3":
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":

    main()
